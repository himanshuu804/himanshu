import React, { useState, useEffect } from 'react';
import { TaskProvider } from './context/TaskContext';
import TaskHeader from './components/TaskHeader';
import TaskStats from './components/TaskStats';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';
import FilterBar from './components/FilterBar';

function App() {
  return (
    <TaskProvider>
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <TaskHeader />
          <TaskStats />
          <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-1">
              <TaskForm />
            </div>
            <div className="lg:col-span-2">
              <FilterBar />
              <TaskList />
            </div>
          </div>
        </div>
      </div>
    </TaskProvider>
  );
}

export default App;