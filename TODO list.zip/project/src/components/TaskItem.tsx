import React, { useState } from 'react';
import { useTaskContext, Task } from '../context/TaskContext';
import { Check, Edit2, Trash2, Calendar, Flag, X, Save } from 'lucide-react';

interface TaskItemProps {
  task: Task;
}

const TaskItem: React.FC<TaskItemProps> = ({ task }) => {
  const { toggleTask, updateTask, deleteTask } = useTaskContext();
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(task.title);
  const [editDescription, setEditDescription] = useState(task.description);
  const [editPriority, setEditPriority] = useState(task.priority);
  const [editDueDate, setEditDueDate] = useState(task.dueDate || '');

  const handleSave = () => {
    if (!editTitle.trim()) return;
    
    updateTask(task.id, {
      title: editTitle.trim(),
      description: editDescription.trim(),
      priority: editPriority,
      dueDate: editDueDate || null,
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditTitle(task.title);
    setEditDescription(task.description);
    setEditPriority(task.priority);
    setEditDueDate(task.dueDate || '');
    setIsEditing(false);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: date.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined
    });
  };

  const isOverdue = task.dueDate && !task.completed && new Date(task.dueDate) < new Date();
  const isDueToday = task.dueDate && new Date(task.dueDate).toDateString() === new Date().toDateString();

  const priorityColors = {
    high: 'bg-red-100 text-red-700 border-red-200',
    medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    low: 'bg-green-100 text-green-700 border-green-200',
  };

  if (isEditing) {
    return (
      <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 border border-white/20 shadow-lg">
        <div className="space-y-3">
          <input
            type="text"
            value={editTitle}
            onChange={(e) => setEditTitle(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            placeholder="Task title..."
          />
          
          <textarea
            value={editDescription}
            onChange={(e) => setEditDescription(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
            rows={2}
            placeholder="Task description..."
          />
          
          <div className="flex gap-2 flex-wrap">
            <select
              value={editPriority}
              onChange={(e) => setEditPriority(e.target.value as 'high' | 'medium' | 'low')}
              className="px-3 py-1 border border-gray-300 rounded-lg text-sm"
            >
              <option value="high">High Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="low">Low Priority</option>
            </select>
            
            <input
              type="date"
              value={editDueDate}
              onChange={(e) => setEditDueDate(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-lg text-sm"
              min={new Date().toISOString().split('T')[0]}
            />
          </div>
          
          <div className="flex gap-2 justify-end">
            <button
              onClick={handleCancel}
              className="px-3 py-1 text-gray-600 hover:text-gray-800 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
            <button
              onClick={handleSave}
              className="px-3 py-1 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors"
            >
              <Save className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`group bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/20 shadow-lg hover:shadow-xl transition-all duration-200 ${
      task.completed ? 'opacity-75' : ''
    } ${isOverdue ? 'border-red-200 bg-red-50/60' : ''}`}>
      <div className="flex items-start gap-3">
        {/* Checkbox */}
        <button
          onClick={() => toggleTask(task.id)}
          className={`flex-shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
            task.completed 
              ? 'bg-green-500 border-green-500 text-white' 
              : 'border-gray-300 hover:border-gray-400'
          }`}
        >
          {task.completed && <Check className="h-3 w-3" />}
        </button>

        {/* Task Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className={`font-medium text-gray-900 ${
              task.completed ? 'line-through text-gray-500' : ''
            }`}>
              {task.title}
            </h3>
            
            {/* Actions */}
            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => setIsEditing(true)}
                className="p-1 text-gray-400 hover:text-blue-500 transition-colors"
                title="Edit task"
              >
                <Edit2 className="h-4 w-4" />
              </button>
              <button
                onClick={() => deleteTask(task.id)}
                className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                title="Delete task"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>

          {task.description && (
            <p className={`text-sm text-gray-600 mt-1 ${
              task.completed ? 'line-through' : ''
            }`}>
              {task.description}
            </p>
          )}

          {/* Task Meta */}
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            {/* Priority Badge */}
            <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full border ${priorityColors[task.priority]}`}>
              <Flag className="h-3 w-3" />
              {task.priority}
            </span>

            {/* Due Date */}
            {task.dueDate && (
              <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full border ${
                isOverdue 
                  ? 'bg-red-100 text-red-700 border-red-200' 
                  : isDueToday
                    ? 'bg-orange-100 text-orange-700 border-orange-200'
                    : 'bg-gray-100 text-gray-600 border-gray-200'
              }`}>
                <Calendar className="h-3 w-3" />
                {formatDate(task.dueDate)}
                {isOverdue && ' (Overdue)'}
                {isDueToday && ' (Today)'}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskItem;