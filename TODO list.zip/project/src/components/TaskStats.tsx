import React from 'react';
import { useTaskContext } from '../context/TaskContext';
import { CheckCircle, Circle, Clock, AlertTriangle } from 'lucide-react';

const TaskStats: React.FC = () => {
  const { state } = useTaskContext();
  const { tasks } = state;

  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.completed).length;
  const activeTasks = totalTasks - completedTasks;
  const overdueTasks = tasks.filter(task => 
    !task.completed && 
    task.dueDate && 
    new Date(task.dueDate) < new Date()
  ).length;

  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/20 shadow-lg">
        <div className="flex items-center gap-3">
          <Circle className="h-8 w-8 text-blue-500" />
          <div>
            <p className="text-2xl font-bold text-gray-900">{totalTasks}</p>
            <p className="text-sm text-gray-600">Total Tasks</p>
          </div>
        </div>
      </div>

      <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/20 shadow-lg">
        <div className="flex items-center gap-3">
          <Clock className="h-8 w-8 text-orange-500" />
          <div>
            <p className="text-2xl font-bold text-gray-900">{activeTasks}</p>
            <p className="text-sm text-gray-600">Active</p>
          </div>
        </div>
      </div>

      <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/20 shadow-lg">
        <div className="flex items-center gap-3">
          <CheckCircle className="h-8 w-8 text-green-500" />
          <div>
            <p className="text-2xl font-bold text-gray-900">{completedTasks}</p>
            <p className="text-sm text-gray-600">Completed</p>
          </div>
        </div>
      </div>

      <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/20 shadow-lg">
        <div className="flex items-center gap-3">
          <AlertTriangle className="h-8 w-8 text-red-500" />
          <div>
            <p className="text-2xl font-bold text-gray-900">{overdueTasks}</p>
            <p className="text-sm text-gray-600">Overdue</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskStats;